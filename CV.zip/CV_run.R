library(quarto)
library(tidyverse)
library(lubridate)
library(here)

here::here()

today <- Sys.Date() %>% strftime(x = ., format = "%d%b%Y") %>% toupper()
time <- gsub(Sys.Date(), "", Sys.time()) %>% str_squish() %>% substr(., 0, 5) %>% gsub(":", "", x = .)

datetime <- paste(today, time, sep = "_")

quarto::quarto_render(input = "CV.qmd", output_file = c(glue::glue("CV_{datetime}.pdf")))

