# This code reads in the data from TLF shell .rtf files and extracts the output type, number, title, analysis set, and cross references.
library(tidyverse)

# Insert path to rtf shell document
listings <- striprtf::read_rtf("") %>%
  split(., cumsum(grepl("^Listing (\\d+\\.)+", .)), drop = TRUE)

listings_table <- map_dfr(
  listings[-1],
  ~{
    number_loc <- grep("^Listing (\\d+\\.)+\\d", .x)
    
    number <- .x[number_loc]
    name <- .x[number_loc + 1]
    set <- grep(pattern = "\\((.*Set)|(All Screened Subjects)\\)", .x, value = T) %>% gsub("\\(|\\)", "", .)
    cross <- grep("Cross-References", .x, value = T) %>% gsub("Cross-References\\:", "", .)
    tibble(
      `Output Number` = number,
      `Output Name` = name,
      `Analysis Level` = "",
      `Analysis Set` = set, 
      `Cross Reference` = cross
    )
  }
) %>%
  separate(col = "Output Number", into = c("Output Type", "Output Number"), sep = "\\s{1}") %>%
  mutate(`Parent Number` = `Output Number`, `Parent Name` = `Output Name`) %>%
  mutate(across(.cols = everything(), .fns = str_squish))

# Insert path to rtf shell document
tables <- striprtf::read_rtf("") %>%
  split(., cumsum(grepl("^\\*\\| Table (\\d+\\.)+", .)), drop = TRUE) 

tables <- striprtf::read_rtf("") %>% 
  split(., cumsum(grepl("^Table (\\d+\\.)+x", ., ignore.case = T)), drop = T)

`%||%` <- function(a, b) {
  
 if (is_empty(a)) {b} else {a}
  
}

tables_table <- map_dfr(
  tables[-1],
  ~{
    parent_table <- .x[[1]] %>% unique()
    meta_table <- grep("^\\*\\| Table", x = .x, value = T) %>% unique()
    cross_table <- grep("Cross-References", x = .x, value = T) %>% str_extract("Cross-References:\\s(Table|Listing|Figure)\\s(\\d+\\.)+\\d(,\\s(Table|Listing|Figure)\\s(\\d+\\.)+\\d)?") %||% ""
    tibble(parent_table, meta_table, cross_table)
  }
) %>% 
  separate(col = meta_table, sep = "\\\n", into = c("Output Number", "Output Name", "Analysis Level", "Analysis Set")) %>%
  mutate(
    `Parent Number` = str_extract(parent_table, "(\\d+\\.)+x"),
    `Parent Name` = gsub("Table (\\d+\\.)+x", "", parent_table),
    `Output Number` = gsub("^\\*\\| ", "", `Output Number`),
    `Analysis Set` = gsub("\\(|\\)", "", `Analysis Set`),
    `Cross Reference` = gsub("Cross-References\\: ", "", cross_table)
  ) %>%
    separate(col = "Output Number", into = c("Output Type", "Output Number"), sep = "\\s{1}") %>%
  select(
    `Output Type`,
    `Parent Number`,
    `Parent Name`,
    `Output Number`,
    `Output Name`,
    `Analysis Level`,
    `Analysis Set`,
    `Cross Reference`
  ) %>%
  mutate(across(everything(), str_squish))




outputs_table <- bind_rows(tables_table, listings_table) %>% mutate(across(everything(), str_squish))

new_outputs <- outputs_table %>% 
  distinct(`Output Type`, `Parent Number`, `Parent Name`, `Analysis Set`, `Cross Reference`) %>%
  group_by(`Output Type`, `Parent Number`) %>%
  nest() %>%
  mutate(
    data = ifelse(`Output Type` == "Table",
                  map2(
                    .x = `Parent Number`,
                    .y = data,
                    ~{
                      # suff <- c("Monotherapy", "Combination Therapy Group A1", "Combination Therapy Group A2", "Combination Therapy B1", "Combination Therapy Group B2")
                      # num <- str_remove(.x, "\\.x") %>% paste(., seq(1:5), "x", sep = ".")
                      suff <- c("Monotherapy", "Combination Therapy")
                      num <- str_remove(.x, "\\.x") %>% paste(., seq(1:2), "x", sep = ".")
                      name <- paste(.y[["Parent Name"]], suff, sep = " - ")
                      out <- .y %>% uncount(2) %>% mutate(`Parent Name` = name, `Parent Number` = num)
                      # out[["Parent Name"]] <- name
                      # out[["Parent Number"]] <- num
                      out
                      }
                    ),
                  map2(
                    .x = `Parent Number`,
                    .y = data,
                    ~{
                      .y %>% mutate(`Parent Number` = .x)
                    }
                  )
                  )) %>%
  ungroup() %>%
  select(-c("Parent Number")) %>%
  unnest(cols= c(data))


# Used to compare to existing list of outputs

dir <- ""
outputs <- list.files(dir, pattern = ".rtf")
rtf_extract <-function(file) {
  meta_pattern <- c("\\\\pard\\\\plain\\\\intbl\\\\keepn\\\\sb10\\\\sa10\\\\qc\\\\f1\\\\fs16\\\\cf1\\{", "\\\\hich\\\\af2\\\\dbch\\\\af31505\\\\loch\\\\f2 (Table|Listing|Figure)")
  
  file_text <- readLines(file, n = 100)
  metadata <- str_subset(pattern = paste(meta_pattern, collapse = "|"), string = file_text) %>%
    str_remove(paste(meta_pattern, collapse = "|")) %>%
    str_remove("\\\\cell\\}") %>%
    stringi::stri_remove_empty()
  metadata

}

results <- map_dfr(outputs, ~{
  meta <- rtf_extract(.x)
  num <- meta[1]
  nam <- meta[min(setdiff(seq_along(meta), range(seq_along(meta))), na.rm = T)]
  set = meta[length(meta)]
  
  tibble(
    `Output Number` = num,
    `Output Name` = nam,
    `Analysis Set` = set %>% gsub("\\(|\\)", "", .)
  )
  
}) %>%
  separate(col = "Output Number", into = c("Output Type", "Output Number"), sep = "\\s{1}") %>%
  mutate(across(everything(), str_squish)) %>%
  mutate(prod = "Y")




e <- outputs %>% 
  str_extract("(\\d+\\-)+") %>% 
  gsub("\\-$", "", .) %>%
  gsub("\\-", "\\.", .) %>%
  as_tibble() %>%
  mutate(prod = "Y", value = gsub("\\.0(\\d)", "\\.\\1", value)) %>%
  rename(`Output Number` = value)
  


outputs_table %>% 
  select(`Output Number`, shell) %>% 
  left_join(e, 
            by = "Output Number") %>%
  filter(is.na(prod))
