ftx_colors <- c("#90BCC1", "#34848E", "#41BEE8", "#17355B",
                "#081D38", "#A9D46F", "#F0B23D", "#E1816D", 
                "#A40E4C", "#6D2E46", "#511C29")

ftx_neutrals <- c(
  "#E6E6E6",
  "#39393A",
  "#56494E"
)

ftx_bl_rd <- c(
  "#90bcc1",
  "#87bbb6",
  "#84b9a7",
  "#89b696",
  "#94b283",
  "#a3ab72",
  "#b4a365",
  "#c5995f",
  "#d58d62",
  "#e1816d"
  )

scales::show_col(ftx_colors)
scales::show_col(ftx_neutrals)
scales::show_col(ftx_bl_rd)
