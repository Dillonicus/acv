# Used to find assumed binomial probability (e.g. response rate) based on lower bound of CI and sample size
# For Dose Expansion
library(tidyverse)
N <- 25 # number planned for dose expansion
alpha <- 0.1 # type-I error rate
th_low <- 0.15 # lower bound of binomial CI
p <- 0.1

purrr::map_dfr(
  .x = seq_len(N),
  .f = ~{
    test <- binom.test(x = .x, n = N, conf.level = 1-alpha, p = p)
    dplyr::tibble(
      N = N,
      success = .x,
      failure = N - .x,
      lowerCI = test$conf.int[1],
      upperCI = test$conf.int[2]
    )
  }
) %>%
  mutate(p = success/N) 
