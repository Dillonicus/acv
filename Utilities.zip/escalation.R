library(tidyverse)
library(magrittr)
# ========== 3+3 Design Considerations w/ No De-escalation ========== #

set.seed(31420)

# setup number of dose groups, dose levels, and predicted dlt rate at each level
dosegrp <- seq(1:7)
doselvl <- c(10, 20, 33, 50, 70, 93, 124)
dltprob <- c(0.010, 0.021, 0.055, 0.173, 0.489, 0.848, 0.983)

dat <- tibble(dosegrp, doselvl, dltprob)

# Step 1: Calculation of probability of escalation at dose j =====

# probability of no DLT in first three subjects in cohort j
# can be represented as (p_j)^0 * (1 - p_j)^3

# If one DLT, additional three are enrolled. probability of dose escalation
# after one DLT in first 3 can be represented as 
# prob(1 DLT in first 3) * prob(<= 1 DLT in additional 3 subjects)

dat %<>% 
  mutate(
    p0 = (dltprob ^ 0) * (1-dltprob)^3,
    p1 = 1 - p0,
    q0 = dbinom(1, 3, prob=dltprob) * pbinom(0, 3, dltprob),
    q1 = 1-q0
  )

# Step 2: Calculation of probability of a dose level as MTD =====

# If MTD is identified as dose level i, we know that all dose levels <= i are
# not too toxic to stop. Probability of entering to next dose cohort at dose i
# is prob((Escalate at dose i) and (MTD >= dose i)) = prod{1 to i}(p_0 + q_0)

# If MTD is identified as dose level i, we also know that all dose levels > i are
# too toxic to continue. Probability of stopping dose escalation at dose i+1 is
# prob((stop at i+1) and (MTD < dose i+1)) = 1-[p0^i+1 + q0^i+1]

dat %<>%
  mutate(
    p_go = cumprod(p0 + q0),
    p_stop = 1 - lead(p0, default = 0) - lead(q0, default = 0)
  )

# The probability that dose i is claimed as MTD, prob(MTD = dose i) is 
# (1 - p0^i+1 - q0^i+1) * prod{1 to i}(p0 + q0).

dat %<>%
  mutate(
    p_mtd = p_go * p_stop
  )

# Step 3: Calculation of expected number of subjects

dat %>% 
  mutate(
    exp_go = ((3 * p0) + (6 * q0)) / (p0 + q0),
    exp_stop = (3 * (1 - p0 + (1 - p0)) + 6 * ((1-p0) - q0)) / (1 - p0 - q0)
  ) 
