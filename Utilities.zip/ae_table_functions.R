

d <- dat_16.2.7.1 %>%
  ungroup() %>%
  filter(saffl == "Y") %>%
  mutate(tr01pg1 = forcats::fct_reorder(tr01pg1, tr01pg1n)) %>%
  select(tr01pg1, tr01pg1n, subjid, aebodsys, aedecod, aerel, trtemfl) %>%
  arrange(tr01pg1, tr01pg1n, subjid, aebodsys, aedecod) %>%
  group_by(tr01pg1, tr01pg1n, subjid, aebodsys, aedecod) %>% 
  filter(row_number() == 1) %>%
  ungroup()

test_fun <- function(data, all_row = "", ...){
  dots <- enquos(...)
  # Get total numbers in each treatment group for calculation of percents
  trt_summary <- data %>% 
    distinct(tr01pg1, tr01pg1n, subjid) %>% 
    count(tr01pg1, tr01pg1n, name = "n_trt") %>%
    bind_rows(., summarize(., n_trt = sum(n_trt), tr01pg1 = "Overall", tr01pg1n = Inf))
  
  # Get total numbers in each treatment group that satisfy table conditions
  trt_filt_summary <- data %>% 
    filter(!!!dots) %>% 
    distinct(tr01pg1, tr01pg1n, subjid) %>% 
    count(tr01pg1, tr01pg1n) %>% 
    bind_rows(., summarize(., n = sum(n), tr01pg1 = "Overall", tr01pg1n = Inf)) %>%
    mutate(aebodsys = all_row, aedecod = "") %>%
    ungroup()
  
  # Body system summary
  sys_summary <- data %>% 
    filter(!!!dots) %>% 
    distinct(tr01pg1, tr01pg1n, subjid, aebodsys) %>% 
    group_by(aebodsys, tr01pg1, tr01pg1n) %>% 
    summarize(n = n()) %>%
    group_by(aebodsys) %>%
    bind_rows(., summarize(., n = sum(n), tr01pg1 = "Overall", tr01pg1n = Inf)) %>%
    mutate(aedecod = "") %>%
    ungroup()
  
  # PT summary
  term_summary <- data %>% 
    filter(!!!dots) %>% 
    distinct(tr01pg1, tr01pg1n, subjid, aebodsys, aedecod) %>% 
    group_by(aebodsys, aedecod, tr01pg1, tr01pg1n) %>% 
    summarize(n = n()) %>%
    group_by(aebodsys, aedecod) %>%
    bind_rows(., summarize(., n = sum(n), tr01pg1 = "Overall", tr01pg1n = Inf)) %>%
    ungroup()
  
  # Table for sorting order
  term_sort <- term_summary %>%
    filter(tr01pg1 == "Overall") %>%
    distinct(aebodsys, aedecod, n) %>%
    rename(n_sort = n)
  
  out <- bind_rows(trt_filt_summary, sys_summary, term_summary) %>%
    left_join(., trt_summary, by = c("tr01pg1", "tr01pg1n"))  %>%
    left_join(., term_sort, by = c("aebodsys", "aedecod")) %>%
    mutate(n_sort = ifelse(is.na(n_sort), Inf, n_sort)) %>%
    mutate(
      prop = n / n_trt,
      stat = glue::glue("{n} ({scales::label_percent(accuracy = 0.1, suffix = '')(prop)})"),
      tr01pg1_n = fct_reorder(.f = glue::glue("{tr01pg1} (N = {n_trt})"), .x = tr01pg1n)
      ) %>%
    arrange(tr01pg1_n, aebodsys, -n, aedecod) %>%
    ungroup() %>%
    pivot_wider(names_from = "tr01pg1_n", values_from = "stat", values_fill = "0", id_cols = c("aebodsys", "aedecod", "n_sort")) %>%
    arrange(aebodsys, -n_sort) %>%
    mutate(aedecod = ifelse(aedecod == "", aebodsys, aedecod)) %>%
    select(-n_sort) %>%
    group_by(aebodsys) %>%
    group_modify(.f = ~{ bind_rows(.x, mutate(.x, across(everything(), function(x) {""}))) }) %>%
    ungroup()
  
  out
}
