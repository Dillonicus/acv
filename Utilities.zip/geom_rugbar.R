geom_rugbar <- function(
    mapping = NULL, data = NULL,
    stat = "identity", position = "identity",
    ...,
    outside = FALSE,
    show.legend = NA,
    na.rm = FALSE,
    inherit.aes = TRUE,
    size = 0.03) {
  
  layer(
    data = data,
    mapping = mapping,
    stat = stat,
    geom = GeomRugBar,
    position = position,
    show.legend = show.legend,
    inherit.aes = inherit.aes,
    params = rlang::list2(
      outside = outside,
      size = size,
      na.rm = na.rm,
      ...
    )
  )
}

GeomRugBar <- ggplot2::ggproto(
  "GeomRugBar",
  required_aes = c("xmin", "xmax"),
  GeomRect,
  rename_size = TRUE,
  draw_layer = function (self, data, params, layout, coord) 
  {
    if (ggplot2:::empty(data)) {
      n <- if (is.factor(data$PANEL)) 
        nlevels(data$PANEL)
      else 1L
      return(rep(list(ggplot2::zeroGrob()), n))
    }
    params <- params[intersect(names(params), self$parameters())]
    args <- c(list(quote(data), quote(panel_params), quote(coord)), 
              params)
    lapply(split(data, data$PANEL), function(data) {
      if (ggplot2:::empty(data)) 
        return(zeroGrob())
      panel_params <- layout$panel_params[[data$PANEL[1]]]
      do.call(self$draw_panel, args)
    })
  },
  draw_panel = function (self, data, panel_params, coord, linejoin = "mitre", outside = FALSE, size = 5) 
  {
    if (!coord$is_linear()) {
      aesthetics <- setdiff(names(data), c("x", "y", "xmin", 
                                           "xmax", "ymin", "ymax", "size"))
      polys <- lapply(split(data, seq_len(nrow(data))), function(row) {
        poly <- ggplot2:::rect_to_poly(row$xmin, row$xmax, row$ymin, 
                             row$ymax)
        aes <- ggplot2:::new_data_frame(row[aesthetics])[rep(1, 5), 
        ]
        GeomPolygon$draw_panel(cbind(poly, aes), panel_params, 
                               coord)
      })
      ggplot2:::ggname("bar", do.call("grobTree", polys))
    }
    else {
      coords <- coord$transform(data, panel_params)
      outside_mult <- ifelse(outside, -1, 1)
      ggplot2:::ggname("geom_rect", 
                       grid::rectGrob(
                         x = unit(coords$xmin, "native"),
                         y = rep(unit(0, "npc"), nrow(coords)),
                         width = unit(coords$xmax - coords$xmin, "native"),
                         height = outside_mult * (unit(coords$size, "pt") - rep(unit(0, "pt"), nrow(coords))), 
                         just = c("left", "bottom"), 
                         gp = grid::gpar(
                           col = coords$colour, 
                           fill = alpha(coords$fill, coords$alpha), 
                           lwd = grid::convertUnit(unit(coords$size, "pt"), "npc")  * .pt, 
                           lty = coords$linetype, 
                           linejoin = linejoin,
                           lineend = ifelse(identical(linejoin, "round"), "round", "square")
                       )))
    }
  }
)
