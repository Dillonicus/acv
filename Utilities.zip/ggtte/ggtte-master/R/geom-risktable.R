#' @title Survival table plot
#' @description
#' Generates a survival table plot.
#' @export
geom_risktable <- function(mapping = NULL, data = NULL, stat = "RiskTable",
                           position = "identity", na.rm = FALSE, show.legend = NA, inherit.aes = TRUE,
                           table.type = "r", ...) {

  l <- layer(
    data = data,
    mapping = mapping,
    stat = stat,
    geom = GeomRiskTable,
    position = position,
    inherit.aes = inherit.aes,
    show.legend = show.legend,
    params = list(
      table.type = table.type,
      na.rm = na.rm,
      ...
    ),
    layer_class = RiskTableLayer
  )
  
  structure(l, class = c("ggtte_layer", "ggtte_risktable", class(l)))
  #structure(l, class = c("ggtte_layer", class(l)))
}

#' @title Risk and Event Table
#' @export
GeomRiskTable <- ggplot2::ggproto("GeomRiskTable", ggplot2::Geom,
                                  setup_data = function(data, params) {
                                    attr(data, "table.type") <- params$table.type
                                    data
                                  },
                                  draw_panel = function (self, data, panel_params, coord, parse = FALSE, na.rm = FALSE,
                                                         check_overlap = FALSE, table.type = "r")
                                  {
                                    
                                    non_aes <- c("estimate", "conf.low", "conf.high", "std.error", "y", "time", "n.risk", "n.censor", "n.event", "cum.event", "cum.censor", "label", "x")
                                    aes <- data %>% select(setdiff(names(.), non_aes)) %>% unique() 
                                    xbreak <- na.omit(panel_params$x$breaks)
                                    
                                    data_update <- data %>% 
                                      group_by(group) %>%
                                      group_modify(~update_times(data = .x, times = xbreak, table.type = table.type)) %>%
                                      #update_times(times = xbreak, table.type = table.type) %>%
                                      left_join(., aes, by = c("strata", "group")) %>%
                                      rename(x = time) %>% mutate(y = strata)
                                    
                                    lab <- data_update$label
                                    if (parse) {
                                      lab <- ggint$parse_safe(as.character(lab))
                                    }
                                    data_update <- coord$transform(data_update, panel_params)
                                    if (is.character(data_update$vjust)) {
                                      data_update$vjust <- ggint$compute_just(data_update$vjust, data_update$y, data_update$x, 
                                                                 data_update$angle)
                                    }
                                    if (is.character(data_update$hjust)) {
                                      data_update$hjust <- ggint$compute_just(data_update$hjust, data_update$x, data_update$y, 
                                                                 data_update$angle)
                                    }
                                    grid::textGrob(lab, data_update$x, data_update$y, default.units = "native", hjust = data_update$hjust, 
                                             vjust = data_update$vjust, rot = data_update$angle, gp = grid::gpar(col = alpha(data_update$colour, 
                                                                                                         data_update$alpha), fontsize = data_update$size * .pt, fontfamily = data_update$family, 
                                                                                             fontface = data_update$fontface, lineheight = data_update$lineheight), 
                                             check.overlap = check_overlap)
                                  
                                  },
                                  default_aes = aes(colour = "black", size = 3.88, angle = 0, hjust = 0.5, vjust = 0.5, alpha = NA, family = "", fontface = 1, lineheight = 1.2),
                                  extra_params = c("table.type")
)
