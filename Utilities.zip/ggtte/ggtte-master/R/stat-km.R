
#' @export

StatKM <- ggplot2::ggproto("StatKM", Stat,
                           compute_group = function(data, scales, type = 'kaplan-meier', trans = 'identity', firstx = 0, firsty = 1) {
                             sf <- survfit.formula(Surv(data$time, data$event) ~ 1, start.time = firstx)
                             sf <- survfit0(sf, start.time = 0)
                             surv_vars <- c("time", "n.risk", "n.event", "n.censor", "surv", "std.err", "lower", "upper")
                             sf_summary <- summary(sf, extend = TRUE, censored = TRUE)
                             sf_summary <- lapply(setdiff(names(sf_summary), c("call", "table")), function(x) sf_summary[x]) %>% 
                               dplyr::bind_cols() %>%
                               mutate(x = time, y = surv)
                             
                             transloc <- scales::as.trans(trans)$trans
                             if(rlang::is_empty(sf_summary)) {
                               time <- rep(sf$time, 2)
                               sf_summary$surv <- rep(1, length(x))
                             }
                             step <- ggint$stairstep(sf_summary, direction = 'hv')
                             step
                           },
                           required_aes = c('time', 'event'),
                           dropped_aes = 'event',
                           default_aes = aes(y = after_stat(surv), x = after_stat(time))
                           )

#' @export
stat_km <- function(mapping = NULL, data = NULL, geom = "KM",
                    position = "identity", show.legend = NA, inherit.aes = TRUE,
                    se = TRUE, trans = "identity", firstx = 0, firsty = 1,
                    type = "kaplan-meier") {
  ggplot2::layer(
    stat = StatKM,
    data = data,
    mapping = mapping,
    geom = geom,
    position = position,
    show.legend = show.legend,
    inherit.aes = inherit.aes,
    params = list(trans = trans, firstx = firstx, firsty = firsty,
                  type = type)
  )

}
