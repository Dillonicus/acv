#' @title Kaplan-Meier plot
#' @export
geom_censor <- function(mapping = NULL, data = NULL, stat = "KM", position = "identity",
                    show.legend = NA, inherit.aes = TRUE, na.rm = TRUE, ...) {
  l <- layer(geom = GeomCensor,
             mapping = mapping,
             data = data,
             stat = stat,
             position = position,
             show.legend = show.legend,
             inherit.aes = inherit.aes,
             params = list(
               na.rm = na.rm,
               ...
             ))
  
  l
}

#' @export
GeomCensor <- ggproto("GeomCensor", Geom,
                  draw_group = function(self, data, panel_params, coord) {
                    if (is.character(data$shape)) {
                      data$shape <- ggplot2:::translate_shape_string(data$shape)
                    }
                    
                    dat <- data %>% filter(n.censor > 0 & n.event == 0)
                    
                    coords <- coord$transform(dat, panel_params)
                    
                    if(nrow(coords) == 0) { grob <- grid::nullGrob() }
                    
                    else{
                    grob <- grid::pointsGrob(coords$x, coords$y, pch = coords$shape, 
                                                           gp = grid::gpar(col = alpha(coords$colour, coords$alpha), fill = alpha(coords$fill, 
                                                                                                                            coords$alpha), fontsize = coords$size * .pt + coords$stroke * 
                                                                       .stroke/2, lwd = coords$stroke * .stroke/2))
                    }
                    
                    ggplot2:::ggname("geom_censor", grob)
                  },
                  default_aes = aes(shape = 3, colour = "black", size = 1.5, fill = NA, alpha = NA, stroke = 0.5),
                  draw_key = ggplot2:::draw_key_point,
                  required_aes = c("x", "y")
)
