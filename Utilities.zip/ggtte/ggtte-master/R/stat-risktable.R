
#' @export
stat_risktable <- function(mapping = NULL, data = NULL, stat = "RiskTable", geom = "text",
                           position = "identity",
                           show.legend = NA,
                           inherit.aes = TRUE,
                           na.rm = FALSE,
                           type = "kaplan-meier",
                           table.type = "r",
                           firstx = 0, firsty = 1, n.breaks = 5, breaks = NULL, ...) {
  ggplot2::layer(
    data = data,
    mapping = mapping,
    stat = StatRiskTable,
    geom = geom,
    position = position,
    show.legend = show.legend,
    inherit.aes = inherit.aes,
    params = list(
      na.rm = na.rm,
      firstx = firstx,
      firsty = firsty,
      table.type = table.type,
      type = type,
      ...)
  )
}


#' @export

StatRiskTable <- ggplot2::ggproto("StatRiskTable", Stat,
                                 
                                  setup_data = function (data, params) 
                                  {
                                    
                                    if(is.null(data$strata)) {
                                      data <- data %>%
                                        mutate(strata = "All")
                                    }
                                    
                                    if(!is.null(data$strata) & !is.discrete(data$strata)) {
                                      stop("The `strata` aesthetic must correspond to a discrete variable at this time.")
                                    }
                                    data
                                  },
                                  compute_group = function(self, data, scales, type = "kaplan-meier", firstx = 0, firsty = 1, table.type = "r") {
                                    
                                    sf <- survfit.formula(Surv(data$time, data$event) ~ data$group, type = type, start.time = firstx)
                                    sf <- survfit0(sf, start.time = 0)
                                    surv_vars <- c("strata", "time", "n.risk", "n.event", "n.censor", "surv", "std.err", "lower", "upper")
                                    sf_summary <- summary(sf, extend = TRUE, censored = TRUE)
                                    sf_summary <- lapply(surv_vars, function(x) sf_summary[x]) %>% 
                                      dplyr::bind_cols() %>%
                                      update_times(table.type = table.type) 
                                     
                                  },
                                 
                                  compute_panel = function (self, data, scales, ...) 
                                  {
                                    if (ggint$empty(data)) 
                                      return(data_frame0())
                                    groups <- split(data, data$group)
                                    stats <- lapply(groups, function(group) {
                                      self$compute_group(data = group, scales = scales, ...)
                                    })
                                    non_constant_columns <- character(0)
                                    stats <- mapply(function(new, old) {
                                      if (ggint$empty(new)) 
                                        return(data_frame0())
                                      old <- old[, !(names(old) %in% names(new)), drop = FALSE]
                                      non_constant <- vapply(old, function(x) length(ggplot2:::unique0(x)) > 
                                                               1, logical(1L))
                                      non_constant_columns <<- c(non_constant_columns, names(old)[non_constant])
                                      vec_cbind(new, old[rep(1, nrow(new)), , drop = FALSE])
                                    }, stats, groups, SIMPLIFY = FALSE)
                                    non_constant_columns <- ggplot2:::unique0(non_constant_columns)
                                    dropped <- non_constant_columns[!non_constant_columns %in% 
                                                                      self$dropped_aes]
                                    if (length(dropped) > 0) {
                                      cli::cli_warn(c("The following aesthetics were dropped during statistical transformation: {.field {glue_collapse(dropped, sep = ', ')}}", 
                                                      i = "This can happen when ggplot fails to infer the correct grouping structure in the data.", 
                                                      i = "Did you forget to specify a {.code group} aesthetic or to convert a numerical variable into a factor?"))
                                    }
                                    data_new <- ggplot2:::vec_rbind0(!!!stats)
                                    data_new <- data_new[, !names(data_new) %in% non_constant_columns, drop = FALSE]
                                    data_new
                                  },
                                  required_aes = c("time", "event"),
                                  default_aes = aes(x = after_stat(time), y = after_stat(strata), label = after_stat(label)),
                                  dropped_aes = c("event")
                                  )
