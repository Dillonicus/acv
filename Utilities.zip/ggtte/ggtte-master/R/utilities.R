#' @import ggplot2
#' @import scales
#' @import grid
#' @import gtable
#' @import rlang
#' @importFrom glue glue glue_collapse

# Data =========================================================================
library(ggplot2)
library(survival)
library(scales)
library(vctrs)
library(gtable)
library(grid)
library(magrittr)
library(dplyr)
library(tidyr)
dat <- survival::colon %>%
  mutate(
    time_months = lubridate::days(time)/lubridate::years(1)
  )

load_files <- function() {
  files <- rev(list.files("C:/Users/dcorrigan/OneDrive - Foghorn Therapeutics/Desktop/Work/Code/ggtte/ggtte-master/R", full.names = T))
  files <- files[!grepl(pattern = "ggtte-package", x = files)]
  sapply(files, source)
}

# load_files()

ggplot(dat %>% filter(etype == 1), aes(time = time_months, event = status, strata = factor(sex))) + geom_km() + geom_risktable()


# Helpers ======================================================================

`%||%` <- function(a, b) {
  if(!is.null(a))
    a
  else b
}

`%|W|%` <- function (a, b)
{
  if (!is.waive(a))
    a
  else b
}

# Type Checks ==================================================================

is.discrete <- function(x) { is.factor(x) || is.character(x) || is.logical(x) }

is.zero <- function (x) { is.null(x) || inherits(x, "zeroGrob") }

is.waive <- function(x) {inherits(x, "waiver")}

is.ggtte <- function(x) {inherits(x, "ggtte")}

is.ggtte_layer <- function(x) {inherits(x, "ggtte_layer")}

is.ggtte_options <- function(x) {inherits(x, "ggtte_options")}

is.ggtte_scale <- function(x) {inherits(x, "ggtte_scale")}

is_theme_complete <- function(x) {
  isTRUE(attr(x, "complete", exact = TRUE))
}

is_theme_validate <- function(x) {
  validate <- attr(x, "validate", exact = TRUE)
  if (is.null(validate))
    TRUE
  else isTRUE(validate)
}
# Survival Functions ===========================================================

#' @export
update_times <- function(data, times = NULL, extend = TRUE, table.type = "r") {

  dat <- data
  
  if (is.null(times)) {
    times <- sort(unique(dat$time))
  }
  
  delta <- function(x, indx) {  # sums between chosen times
    if (is.logical(indx)) indx <- which(indx)
    if (!is.null(x) && length(indx) >0) {
      fx <- function(x, indx) diff(c(0, c(0, cumsum(x))[indx+1]))
      if (is.matrix(x)) {
        temp <- apply(x, 2, fx, indx=indx)
        # don't return a vector when only 1 time point is given
        if (is.matrix(temp)) temp else matrix(temp, nrow=1)
      }
      else fx(x, indx)
    }
    else NULL
  }
  
  ssub<- function(x, indx) {  #select an object and index
    if (!is.null(x) && length(indx)>0) {
      if (is.matrix(x)) x[pmax(1,indx),,drop=FALSE]
      else if (is.array(x))  x[pmax(1,indx),,,drop=FALSE]
      else x[pmax(1, indx)]
    }
    else NULL
  }
  
  attribs <- attributes(dat)
  
  if (FALSE) {
    if (is.null(attribs$start.time)) { mintime <- min(data$time, 0) }
    else { 
      mintime <- attribs$start.time 
      ptimes <- times[times >= mintime]
    }
  } else ptimes <- times[is.finite(times)]
  
  if (!extend) {
    maxtime <- max(dat$time)
    ptimes <- ptimes[ptimes <= maxtime]
  }
  ntime <- length(unique(dat$time))
  index1 <- findInterval(ptimes, dat$time)
  index2 <- 1 + findInterval(ptimes, dat$time, left.open = TRUE)
  
  out <- list()
  for (i in c("estimate", "conf.low", "conf.high", "std.error", "group", "y", "strata")) {
    out[[i]] <- ssub(dat[[i]], index1)
  }
  
  out$time <- ptimes
  out$n.risk <- c(dat$n.risk, 0)[index2]
  out$n.censor <- dat$n.censor
  out$n.event <- dat$n.event
  
  for (i in c("n.event", "n.censor")) {
    j <- gsub("^n\\.", "cum\\.", i)
    out[[j]] <- cumsum(delta(out[[i]], index1))
    out[[i]] <- ssub(out[[i]], index1)
  }
  
  out <- tibble::as_tibble(out)
  
  labels <- switch(
    table.type,
    r = glue::glue("{out$n.risk}"),
    re = glue::glue("{out$n.risk} ({out$n.event})"),
    rc = glue::glue("{out$n.risk} ({out$n.censor})"),
    rce = glue::glue("{out$n.risk} ({out$cum.event})"),
    rcc = glue::glue("{out$n.risk} ({out$cum.censor})")
  )
  
  out$label <- labels
  
  return(out)
  
}

# Old function
cut_timepoints <- function(sf, table.type = "r") {
  sf_est <- broom::tidy(sf)
  labels <- switch(
    table.type,
    r = glue::glue("{sf_est$n.risk}"),
    re = glue::glue("{sf_est$n.risk} ({sf_est$n.event})"),
    rc = glue::glue("{sf_est$n.risk} ({sf_est$n.censor})"),
    rce = glue::glue("{sf_est$n.risk} ({sf_est$cum.event})"),
    rcc = glue::glue("{sf_est$n.risk} ({sf_est$cum.censor})")
  )
  sf_est$label <- labels
  sf_est
}

#' @importFrom dplyr %>%
tidy.survfit <- function (x, ...)
{
  strata <- time <- n.event <- n.censor <- NULL
    if (inherits(x, "survfitms")) {
      ret <- tibble::tibble(
        time = x$time,
        n.risk = c(x$risk),
        n.event = c(x$n.event),
        n.censor = x$n.censor,
        estimate = x$pstate,
        std.error = x$std.err,
        conf.high = x$conf.high,
        conf.low = x$conf.low,
        state = rep(x$states, each = nrow(x$pstate))
      )
      
      ret <- ret[ret$state != "", ]
    }
    else {
      ret <- tibble::tibble(
        time = x$time,
        n.risk = x$n.risk,
        n.event = x$n.event,
        n.censor = x$n.censor,
        estimate = x$surv,
        std.error = x$std.err,
        conf.high = x$upper,
        conf.low = x$lower
      )
      
    }
    if (!is.null(x$strata)) {
      ret$strata <- rep(names(x$strata), x$strata)
      strata_var <- quo(strata)
    } else {strata_var <- NULL}
  
    
  
  ret <- ret %>%
    dplyr::arrange(time) %>%
    dplyr::group_by(!!strata_var) %>%
    dplyr::mutate(
      cum.event = cumsum(n.event),
      cum.censor = cumsum(n.censor)
    )
  return(ret)
}

tidysurv <- function (x, ...) 
{
  strata <- time <- n.event <- n.censor <- NULL
  if (inherits(x, "survfitms")) {
    ret <- data.table::data.table(time = x$time, n.risk = c(x$n.risk), 
                                  n.event = c(x$n.event), n.censor = c(x$n.censor), 
                                  estimate = c(x$pstate), std.error = c(x$std.err), 
                                  conf.high = c(x$upper), conf.low = c(x$lower), state = rep(x$states, 
                                                                                             each = nrow(x$pstate)))
    ret <- ret[ret$state != "", ]
  }
  else {
    ret <- data.table::data.table(time = x$time, n.risk = x$n.risk, 
                                  n.event = x$n.event, n.censor = x$n.censor, estimate = x$surv, 
                                  std.error = x$std.err, conf.high = x$upper, conf.low = x$lower)
  }
  if (!is.null(x$strata)) {
    ret$strata <- rep(names(x$strata), x$strata)
    data.table::setkey(ret, strata)
  }
  ret[order(time), `:=`(cum.event = cumsum(n.event), cum.censor = cumsum(n.censor)), 
      by = setdiff("", data.table::key(ret))]
  ret[]
}

# ggside =======================================================================

do_by <- function (data, by, fun, ...)
{
  order_cache <- do.call("order", lapply(by, function(x) {
    data[[x]]
  }))
  data <- data[order_cache, ]
  split_by <- interaction(data[, by, drop = F], drop = T, lex.order = T)
  data <- dplyr::bind_rows(lapply(split(data, split_by), FUN = fun,
                                 ...))
  data <- data[order(order_cache), ]
  rownames(data) <- seq_len(nrow(data))
  data
}

wrapup <- function (df, by, ...)
{
  if (...length() == 0)
    return(df)
  indx <- interaction(df[, by], drop = T)
  indx <- match(indx, unique(indx))
  dots_ <- list(...)
  if (!all(unlist(lapply(dots_, function(x, y) {
    all(x %in% y)
  }, y = colnames(df)))))
    abort("all RHS must exist in column names of `df`.")
  wrap_columns <- unlist(dots_)
  l_ <- split(df, indx)
  l_ <- lapply(l_, function(x, d) {
    wrap <- lapply(d, function(y) list(x[, y, drop = FALSE]))
    x <- unique(x[, setdiff(colnames(x), wrap_columns), drop = FALSE])
    x[, names(d)] <- wrap
    x
  }, d = dots_)
  data <- dplyr::bind_rows(l_)
  data
}

unwrap <- function (df, by, cols = NULL)
{
  if (is.null(cols))
    return(df)
  if (!all(cols %in% colnames(df)))
    abort("all `cols` must exist in column names of `df`")
  indx <- interaction(df[, by], drop = T)
  indx <- match(indx, unique(indx))
  l_ <- split(df, indx)
  l_ <- lapply(l_, function(x) {
    nest <- do.call("cbind", unlist(Map(function(d,
                                                 y) {
      d[, y, drop = T]
    }, d = list(x), y = cols), recursive = F))
    x <- x[, setdiff(colnames(x), cols), drop = FALSE]
    if (nrow(x) != 1)
      stop("by must uniquely index df")
    cbind(x[rep(1, nrow(nest)), ], nest)
  })
  data <- dplyr::bind_rows(l_)
  data
}

# Class Checks =================================================================

#' @export
ggtte <- function(pos = "bottom", scales = "fixed", collapse = NULL) {
  structure(
    list(
      pos = pos,
      scales = scales,
      collapse = collapse,
      risktable = NULL
    ), class = c("ggtte_options", "gg")
  )
}


