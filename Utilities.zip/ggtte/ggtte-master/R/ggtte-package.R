#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom broom tidy
#' @importFrom data.table :=
#' @importFrom glue glue
#' @importFrom glue glue_collapse
#' @importFrom magrittr %>%
#' @importFrom rlang .data
#' @importFrom stats setNames
## usethis namespace: end
NULL
