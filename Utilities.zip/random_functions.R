# This function takes interval objects created by lubridate and combines
# any that overlap defined by a grouping variable
int_merge <- function(x) {
  if(length(x) == 1) return(x)
  x <- x[order(lubridate::int_start(x))]
  y <- x[1]
  for(i in 2:length(x)){
    if(lubridate::int_overlaps(y[length(y)], x[i]))
      y[length(y)] <- lubridate::interval(start = min(lubridate::int_start(c(y[length(y)], x[i]))),
                                          end = max(lubridate::int_end(c(y[length(y)], x[i]))))
    else
      y <- c(y, x[i])
  }
  return(y)
}

# Function to collapse time intervals. Some subjects have
# continuous dosing intervals (i.e. without a dose modification) split up into 
# multiple separate rows/intervals. This function collapses these into one 
# interval for plotting purposes

collapse_intervals <- function(dat) {
  sub <- tibble(dat)
  
  sub <- sub %>%
    arrange(usubjid, exseq) %>%
    mutate(
      # format variables as datetime
      exstdt_dt = as_datetime(exstdt),
      exendt_dt = exendt + days(1) - seconds(0.1),
      trtsdt_dt = as_datetime(trtsdt)
    ) %>%
    group_by(usubjid) %>%
    # For a particular dosing interval, check to see if the interval end date 
    # equals the start date of the next interval. If not, set the end date to the
    # start date of the next interval. If so, keep original recorded end date.
    # This makes sure there are no gaps between intervals.
    mutate(
      # new variable for start date of following interval
      exstdt_lead = lead(exstdt_dt),
      # updates end day variable according to rule above
      exendt_dt = if_else(!is.na(exstdt_lead) & exendt_dt != exstdt_lead, exstdt_lead, exendt_dt), 
      # create time interval
      date_int = lubridate::interval(exstdt_dt, exendt_dt)
    )
  
  sub %>% 
    # collapse overlapping intervals, grouped by subject and dosing group.
    group_by(usubjid, dosegrp, trtsdt, trtsdt_dt) %>%
    summarize(collapsed_int = int_merge(date_int)) %>%
    # sort
    arrange(usubjid, collapsed_int) %>%
    # create new start/end dates and relative days
    mutate(
      exstdt_new = int_start(collapsed_int),
      exendt_new = int_end(collapsed_int),
      exstdy_new = round(as.numeric(exstdt_new - trtsdt_dt, 'days') + 1),
      exendy_new = round(as.numeric(exendt_new - trtsdt_dt, 'days') + 1)
    ) %>%
    group_by(usubjid) %>%
    mutate(
      # create new seqence number
      seq = row_number()
    )
}